package com.example.thenewsapp.ui.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.View
import android.webkit.WebViewClient
import androidx.navigation.fragment.navArgs
import com.example.thenewsapp.R
import com.example.thenewsapp.databinding.FragmentArticleBinding
import com.example.thenewsapp.ui.NewsActivity
import com.example.thenewsapp.ui.NewsViewModel
import com.google.android.material.snackbar.Snackbar

class ArticleFragment : Fragment(R.layout.fragment_article) {
    private lateinit var newsViewModel: NewsViewModel
    private lateinit var binding: FragmentArticleBinding
    private val args: ArticleFragmentArgs by navArgs()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding = FragmentArticleBinding.bind(view)

        newsViewModel = (activity as NewsActivity).newsViewModel

        // Kiểm tra xem đối số "article" đã được truyền hay chưa
        val article = args.article

        if (article != null) {
            binding.webView.apply {
                webViewClient = WebViewClient()
                article.url?.let {
                    loadUrl(it)
                }
            }

            binding.fab.setOnClickListener {
                newsViewModel.addToFavourites(article)
                Snackbar.make(view, "Added to favourites", Snackbar.LENGTH_SHORT).show()
            }
        } else {
            // Nếu không có article được truyền, bạn có thể hiển thị một thông báo hoặc thực hiện các xử lý khác tùy theo yêu cầu của bạn
            Snackbar.make(view, "No article to display", Snackbar.LENGTH_SHORT).show()
        }
    }
}
