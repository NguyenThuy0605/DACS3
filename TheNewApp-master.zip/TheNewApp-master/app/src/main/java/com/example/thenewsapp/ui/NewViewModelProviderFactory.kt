package com.example.thenewsapp.ui

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.thenewsapp.reponsitory.NewsReponsitory

class NewViewModelProviderFactory(val app: Application, val newsReponsitory: NewsReponsitory): ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return NewsViewModel(app,  newsReponsitory) as T
    }
}