package com.example.thenewsapp.util

class Constants {
    companion object{
        const val API_KEY ="f9d8939979da48f58c2a8c256178d32b"
        const val BASE_URL="https://newsapi.org/"
        const val SEARCH_NEWS_TIME_DELAY =500L
        const val QUERY_PAGE_SIZE = 20

    }
}